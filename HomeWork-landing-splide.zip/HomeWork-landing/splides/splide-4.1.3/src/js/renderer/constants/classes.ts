export const CLASS_RENDERED = 'is-rendered';
